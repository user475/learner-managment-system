package com.jpmc.lerner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmc.lerner.models.Course;
import com.jpmc.lerner.models.TeacherStudentMapping;
import com.jpmc.lerner.repository.CourseRepository;
import com.jpmc.lerner.repository.TeacherMappingRepository;

@Service
public class CourseServiceImpl implements CourseService {

	public CourseServiceImpl() {
		System.out.println("CourseServiceImpl");
	}

	@Autowired
	CourseRepository courseRepository;
	
	@Autowired
	TeacherMappingRepository teacherMappingRepository;
	
	
	
	@Override
	public List<Course> getAllCourses(Integer sid) {
		List<Course> courseList = courseRepository.getAllUnRegisterdCourses(sid);
		return courseList;
	}

	
	@Override
	public List<TeacherStudentMapping> getAllrequests(Integer teacherId) {
		List<TeacherStudentMapping> list = teacherMappingRepository.getAllRequestsOfTeacher(teacherId);
		return list;
	}


	@Override
	public List<Course> getAllAcceptedCourses(Integer studentId) {
		List<Course> listAcceptedCourses = courseRepository.getAllAcceptedCourses(studentId);
		return listAcceptedCourses;
	}


	@Override
	public Course saveCourse(Course course) {
		Course dbCourse = courseRepository.save(course);
		
		
		return dbCourse;
	}


	@Override
	public List<Course> allCoursesByTeacherId(Integer teacherId) {
		List<Course> listCourses = courseRepository.findByTeacherId(teacherId);
		
		
		
		return listCourses;
	}

}
