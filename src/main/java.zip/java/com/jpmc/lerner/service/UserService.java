package com.jpmc.lerner.service;
import java.util.List;
import com.jpmc.lerner.models.User;



public interface UserService {

	public List<User> getAllUsers();
	
	public Integer registerUser(User user);
	
	public User getUserByUserName(String userName);
	

}
