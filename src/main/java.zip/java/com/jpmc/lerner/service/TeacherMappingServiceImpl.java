package com.jpmc.lerner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpmc.lerner.models.Course;
import com.jpmc.lerner.models.TeacherStudentMapping;
import com.jpmc.lerner.repository.TeacherMappingRepository;

@Service
public class TeacherMappingServiceImpl  {

	public TeacherMappingServiceImpl() {
		System.out.println("CourseServiceImpl");
	}

	
	/*
	 * @Autowired TeacherMappingRepository teacherMappingRepository;
	 * 
	 * 
	 * 
	 * @Override public List<Course> getAllCourses() { List<Course> courseList =
	 * courseRepository.findAll(); return courseList; }
	 * 
	 * 
	 * @Override public List<TeacherStudentMapping> getAllrequests(Integer
	 * teacherId) { List<TeacherStudentMapping> list =
	 * teacherMappingRepository.getAllRequestsOfTeacher(teacherId); return list; }
	 */

}
