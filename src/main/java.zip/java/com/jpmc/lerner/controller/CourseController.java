package com.jpmc.lerner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jpmc.lerner.models.Course;
import com.jpmc.lerner.models.TeacherStudentMapping;
import com.jpmc.lerner.service.CourseService;

@Controller
public class CourseController {

	@Autowired
	private CourseService courseService;

	@Autowired
	private ApplicationContext applicationContext;

	@GetMapping("/student/home")
	public String getCourseList(Model model, @CookieValue("userName") String userName,
			@CookieValue("userId") Integer sid) {
		model.addAttribute("userName", userName);
		List<Course> allCourses = courseService.getAllCourses(sid);
		model.addAttribute("course", allCourses);
		return "courseList.html";

	}

	@GetMapping("/teacher/home")
	public String getRequestList(Model model, @CookieValue("userId") Integer teacherId,
			@CookieValue("userName") String userName) {
		model.addAttribute("userName", userName);
		List<TeacherStudentMapping> listOfRqs = courseService.getAllrequests(teacherId);
		// listOfRqs.stream().forEach(System.out::println);
		model.addAttribute("list", listOfRqs);
		return "teacher-home.html";

	}

	@GetMapping("/student/status")
	public String checkStatus(Model model, @CookieValue("userId") Integer userId,
			@CookieValue("userName") String userName) {
		model.addAttribute("userName", userName);
		List<Course> list = courseService.getAllAcceptedCourses(userId);
		model.addAttribute("course", list);
		return "myCources.html";

	}

	@GetMapping("/teacher/add-course")
	public String addCourse(Model model, @CookieValue("userId") Integer userId,
			@CookieValue("userName") String userName) {
		model.addAttribute("userName", userName);
		Course bean = applicationContext.getBean(Course.class);

		model.addAttribute("course", bean);

		return "add_course.html";

	}

	@PostMapping("/teacher/add-course")
	@ResponseBody
	public void addCourse(@ModelAttribute Course course, @CookieValue("userId") Integer userId,
			@CookieValue("userName") String userName) {
		System.out.println("userName" + userName);
		course.setTeacherId(userId);
		course.setTeacherName(userName);
		Course saveCourse = courseService.saveCourse(course);
		System.out.println("saveCourse"+saveCourse.toString());

	}
	
	@GetMapping("/teacher/courses")
	public String teacherCourseList( @CookieValue("userId") Integer userId,Model model){
		List<Course> allCoursesByTeacherId = courseService.allCoursesByTeacherId(userId);
		
		model.addAttribute("courseList", allCoursesByTeacherId);
		return "teacher-course-list.html";
	}

}
