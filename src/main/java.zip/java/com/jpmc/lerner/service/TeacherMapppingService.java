package com.jpmc.lerner.service;

import java.util.List;

import com.jpmc.lerner.models.TeacherStudentMapping;

public interface TeacherMapppingService {



	public List<TeacherStudentMapping> getAllrequests(Integer teacherId);

}
