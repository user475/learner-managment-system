package com.jpmc.lerner.service;

import com.jpmc.lerner.models.Mapping;

public interface MappingService {

	public Mapping getMapingByCourseIdAndStudentID(Integer studentId, Integer courseId);

	public Integer saveMapping(Mapping mapping);

	public Integer updateMapping(Integer mappingId);

}
